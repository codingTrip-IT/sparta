# 언젠간되겠지 소개 페이지 온보딩 프로젝트 입니다

#### 파이어베이스 members 테이블입니다

| 컬럼명      | 타입   |
| ----------- | ------ |
| member_id   | String |
| name        | String |
| content     | String |
| profile_url | String |
| createdAt   | Date   |

확인
